﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using LibWorker;
namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodAdd1()
        { //Предпологаеться True
            DateTime date1 = new DateTime(2022, 7, 12, 18, 30, 25);
            var result = WorkerFun.AddWorker(1, "Иванов Иван Иванович", "срочный", date1);
            Assert.AreEqual(true, result);
        }
        [TestMethod]
        public void TestMethodAdd2()
        {   //Попытка добавить Статуc которого нету, разрешены: "обычный" или "срочный" или "транзит")
            //Предпологаеться Fasle
            DateTime date1 = new DateTime(2022, 7, 12, 18, 30, 25);
            var result = WorkerFun.AddWorker(1, "Иванов Иван Иванович", "Такой", date1);
            Assert.AreEqual(false, result);
        }
        [TestMethod]
        public void TestMethodAdd3()
        {   //Вместо ФИО null
            //Предпологаеться Fasle
            DateTime date1 = new DateTime(2022, 7, 12, 18, 30, 25);
            var result = WorkerFun.AddWorker(1, null, "срочный", date1);
            Assert.AreEqual(false, result);
        }
        public void TestMethodDel1()
        {   //Попытка удалить пользователя по ID
            //Предпологаеться True
            DateTime date1 = new DateTime(2022, 7, 12, 18, 30, 25);
            WorkerFun.AddWorker(1, "Иванов Ивано Иванович", "срочный", date1);
            var result = WorkerFun.DelWorker(1);
            Assert.AreEqual(true, result);

        }
        public void TestMethodDel2()
        {    //Попытка удалить пользователя по ID котрого нету 
            //Предпологаеться false
            DateTime date1 = new DateTime(2022, 7, 12, 18, 30, 25);
            WorkerFun.AddWorker(1, "Иванов Ивано Иванович", "срочный", date1);
            var result = WorkerFun.DelWorker(99);
            Assert.AreEqual(false, result);

        }
    }
}
