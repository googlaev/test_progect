﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            setup();
        }



    public void setup()
        {
            dataGrid.ItemsSource = null;
            dataGrid.ItemsSource = App.DB.Table.ToList();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            DateTime dat1;


            DateTime? selectedDate = calendar.SelectedDate;
            if (selectedDate != null)
            {
                 dat1 = (DateTime)selectedDate;
            }
            else
            {
                dat1 = DateTime.Now;
            }

            Table table = new Table {
                kay_id = Convert.ToInt32(textBox.Text),
                name = textBox1.Text,
                types = textBox2.Text,
                data = dat1
            };
            App.DB.Table.Add(table);
            App.DB.SaveChanges();
            setup();




        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            var a =(Table) dataGrid.SelectedItem;
            App.DB.Table.Remove(a);
            App.DB.SaveChanges();
            MessageBox.Show( $"Удален: {a.name}");
            setup();
            
        }
    }
}
