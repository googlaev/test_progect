﻿using System;

namespace LibWorker
{
    public class Worker

    {
        public int ID;
        public string Name;
        public string Types;
        public DateTime Data;
    
    }
}
