﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibWorker
{
  public static class WorkerFun
    { 
       //Список Сотрудников 
       public static List<Worker> ListWorker = new List<Worker>();
        //Дата последнего выданного пропуск
        public static DateTime LastWorker { get
            {
                var LastTime = ListWorker.Count-1;

                return ListWorker[LastTime].Data;
            } 
        }
        //Добавление сотрудника
      static  public bool AddWorker(int? ID, string Name, String Types,DateTime Data)
        { try
            {
                if (ID != null && Name != null && (Types == "обычный" || Types == "срочный" || Types == "транзит"))

                {  
                    Worker WorkerOne = new Worker
                    {
                        ID = (int)ID,
                        Name = Name,
                        Types = Types,
                        Data = Data
                    };
                    ListWorker.Add(WorkerOne);
                    return true;
                }
                else return false;  
               
            }
            catch(Exception e)
            {
                return false;
            }
        }
        //Удаление Сотрудника
      static public bool DelWorker(int ID)
        { 
            try
            {
                foreach (var i in ListWorker)
                {
                    if (i.ID == ID)
                    {
                        ListWorker.Remove(i);
                        return true;
                    }
                   
                }

               return false;
            }
            catch(Exception e)
            {
                return false;
                
            }
           
        }
        // Количества пропусков, выданных в заданный промежуток.
        static public int CountData( DateTime StartWorkerData, DateTime LastWorkerData)
        {
            var StartData = StartWorkerData;
            var EndDatat = LastWorkerData;
            var  Staus = 0;
            var CountD = 0;
            foreach(var start in ListWorker)
            {
                if (start.Data == StartData)
                {
                    Staus = 1; 
                }
                if (start.Data == EndDatat)
                {
                    Staus = 0;
                }
                if (Staus == 1)
                {
                    CountD++;
                }
              


            }

            return CountD + 1;

        }

        
    }
}
