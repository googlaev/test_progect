﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibWorker;
namespace ConsoleApp3
{
    class Program
    {

        static void Main(string[] args)
        {
           
           //Даты для добавления
            DateTime date1 = new DateTime(2015, 1, 20, 18, 30, 25);
            DateTime date2 = new DateTime(2015, 2, 20, 18, 30, 25);
            DateTime date3 = new DateTime(2015, 3, 20, 18, 30, 25);
            DateTime date4 = new DateTime(2020, 7, 20, 18, 30, 25);
            DateTime date5 = new DateTime(2021, 7, 20, 18, 30, 25);
            DateTime date6 = new DateTime(2022, 7, 12, 18, 30, 25);

           
            //Добавление пользователей           
            WorkerFun.AddWorker(0, "Иванов Иван Иванович", "транзит", date1);
            WorkerFun.AddWorker(1, "Сергеев Иван Иванович", "срочный", date2);
            WorkerFun.AddWorker(2, "Иванов Иван Иванович", "обычный", date3);
            WorkerFun.AddWorker(3, "Васильев Иван Иванович", "срочный", date4);
            WorkerFun.AddWorker(4, "Иванов Иван Иванович", "обычный", date5);
            WorkerFun.AddWorker(5, "Иванов Иван Иванович", "срочный", date5);
            


            for (int i = 6; i < 10; i++)
            {
                for (int j = 0; j < 500000000; j++) ;// Задержка по времени
               
               var st =  WorkerFun.AddWorker(i, "Иванов Иван Иванович", "обычный", DateTime.Now);
                if (st) Console.WriteLine("Пользователь добавлен");
                else Console.WriteLine("Пользоваль не добавлен");
            
            }
            // Проверка что не правельные поля пользователь не добавляеться
            var st7 = WorkerFun.AddWorker(15, "Иванов Иван Иванович", "Виу", DateTime.Now);
            if (st7) Console.WriteLine("Пользователь добавлен");
            else Console.WriteLine("Пользоваль не добавлен");
            // Проверка  удаляет по ID
            var st1 = WorkerFun.DelWorker(1);
            if (st1) Console.WriteLine("Пользоватль удален");
            else Console.WriteLine("Пользователь не удален");
            
            // Проверка если нету ID не удаляет
            var st2 = WorkerFun.DelWorker(99);
            if (st2) Console.WriteLine("Пользоватль удален");
            else Console.WriteLine("Пользователь не удален");

            //ВЫвод списка пользователей и дата 
            foreach (var i in WorkerFun.ListWorker)
            {
               
                    Console.WriteLine(i.Name);
                    Console.WriteLine(i.Data);
            }
            // Дата последней регистрации
            Console.WriteLine(WorkerFun.LastWorker);
            //Вывод количества зарегистрированных от даты1 до даты2 включительно. 
            Console.WriteLine(WorkerFun.CountData(date1, date4));


            Console.ReadKey();
        }
    }
}
